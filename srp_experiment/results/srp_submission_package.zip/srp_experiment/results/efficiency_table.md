| Backend | Model | Cycles |
| --- | --- | --- |
